# CadForge — local CAD application

Open **CadForge.html** in a modern desktop browser. It is a self-contained application and does not require installation or a server. Use Save project to keep a durable editable copy; browser autosave is best effort. Separate JavaScript files are the editable source modules already bundled into the HTML.

## Available workflows

- **Draft:** lines, straight polylines, rectangles, circles, segmented arcs and text; exact coordinates; relative coordinates; endpoint/grid snapping; orthogonal drafting.
- **Select/edit:** single and Shift-click multiple selection, window selection, Select all, move/copy/rotate/scale/mirror, erase, explode, properties, undo/redo.
- **Modify:** signed line/circle offset; line trim and extend against line boundaries; equal-distance chamfer between two lines sharing an endpoint.
- **Blocks:** define selected entities as a reusable template, insert copies, transform/delete groups, explode them. DXF output uses BLOCK and INSERT records for grouped geometry.
- **Annotate:** aligned dimensions represented by editable lines/text, length/area measurement, diagonal hatching within a circle or simple closed polyline. Hatch lines form an editable group.
- **Layouts:** save and restore model-view presets. Print sheet opens monochrome vector output for A4, A3 or Letter, with a Print / Save as PDF button. Use a regular browser if the embedded preview prevents printing or pop-ups.
- **3D meshes:** extrude simple closed polygon/circle boundaries to positive height, create boxes, orbit and zoom, translate/copy meshes, union/subtract/intersect two meshes, and export OBJ or ASCII STL triangle meshes. Select a boundary in Model 2D, then choose View → Extrude. Extrusion retains the 2D source. 3D geometry is saved in project JSON and exported separately from DXF.
- **Files:** project JSON; supported ASCII DXF import/export; visible 2D SVG export; 3D OBJ/STL export.

## Commands and controls

Home contains drawing and modification tools. Insert contains block and drafting tools; Annotate contains dimensions, text, measurement and hatching; View contains layouts and 3D tools; Manage contains project output tools.

Enter `x,y` for an exact point, or `@x,y` relative to the preceding construction point. Enter ends a polyline; Escape cancels. Shift-click adds/removes entities, Ctrl+A selects visible entities, Delete erases the selection, Ctrl+Z/Y undo/redo, F8 toggles Ortho, F9 toggles snapping. Mouse wheel zooms; middle/right drag pans in 2D; drag orbits in 3D.

Aliases: L, PL, C, REC, M, CO, E, RO, SC, MI, O, TR, EX, DIM, A. Commands also include SELECTALL, BLOCK, INSERT, EXPLODE, HATCH, CHAMFER, LAYOUT, RESTORELAYOUT, PLOT, EXTRUDE, BOX, ORBIT, MODEL and OBJ. Tools requiring numeric values or names use in-app dialogs.

Arc construction: center, start point, then end direction, counterclockwise. Dimension construction: first point, second point, then dimension-line position. For Move/Copy: select entities, choose tool, specify base and destination.

## Compatibility and remaining work

This is an independent CAD prototype, not a finished AutoCAD replacement. Native DWG, AutoLISP/.NET/ObjectARX plugins, parametric constraints, associative dimensions, specialist toolsets, a B-rep solid kernel are not implemented. Mesh boolean operations are available, but are not a CAD-grade solid kernel. No DWG engine or Autodesk SDK is included.

DXF support covers LINE, CIRCLE, TEXT, straight POLYLINE, LWPOLYLINE (including tessellated bulges), tessellated ARC, and supported BLOCK/INSERT geometry. Unsupported entities are omitted with a warning; binary DXF is rejected. Nested block expansion is limited. Nonuniformly scaled circles become segmented ellipses. Object-coordinate-system transforms, attributes, text rotation, custom styles and many other DXF attributes are not preserved. Colors export as color index 7. Group instances export with generated block names; original block naming and shared-instance editing semantics are not retained. Inspect imported/exported drawings before use.

Arcs and hatches are approximations or primitives. Dimensions do not update when measured geometry changes. Text stays horizontal through transforms. Saved layouts are model-view presets, not paper space with independently editable viewports. 3D is a mesh modeler; extrusion accepts simple polygons without holes, uses circles approximated by 64-sided polygons. Internal circles are not automatically treated as holes; extrude a cutter mesh and use Subtract A − B. Booleans accept at most 5000 input triangles and use floating-point BSP operations; complex geometry may fail or fragment. Mesh results are not guaranteed to have a manifold indexed topology.

## Verification

Automated checks cover bundled initialization, blocks and grouped transforms, hatch undo/redo, explode, extend, chamfer, layout restoration, DXF BLOCK/INSERT round trips, arc and bulge endpoints, invalid-file rejection, convex/concave extrusion, closed mesh edges, signed extrusion volume, project validation and 3D rendering. Boolean checks cover known volumes for overlapping boxes, coplanar faces, identical subtraction and disjoint results. The drilled L-bracket sample has its volume checked independently. Browser checks cover drawing, ribbon tabs, in-app extrusion input, project import, mesh translation and union. Full interoperability with AutoCAD has not been tested.

## Sample and third-party component

Open **L-Bracket.cadforge.json** for a 2D outline plus a 3D bracket with three cut-through holes. **L-Bracket.dxf** contains its 2D drawing; **L-Bracket.obj** contains its 3D triangle mesh. Drawing units are arbitrary.

Mesh boolean operations use Evan Wallace's MIT-licensed [csg.js](https://github.com/evanw/csg.js/), bundled locally in the HTML and retained as csg-library.js. Preserve CSG-LICENSE.txt when redistributing. Source snapshot SHA-256: 3E0055252407536964B9A12AD793B6475A9D53C59B088E93794D91F45D4ADFCD. No external network requests are made at runtime.
